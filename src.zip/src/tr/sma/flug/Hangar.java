package tr.sma.flug;

import java.util.ArrayList;

public class Hangar {
    ArrayList<Flugzeug> flugzeugList;
    Flugzeug flugzeug;
}
